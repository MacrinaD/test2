package Homework4;

public class SistemSolar {

    private int nr_Planete;

    public SistemSolar()
    {
        System.out.println("Costructor fara arg");
    }
    public SistemSolar(int Planete)
    {
        this.nr_Planete=Planete;
    }
    public void setPlanete(int Planete){
        this.nr_Planete=Planete;
    }
    public int getPlanete()
    {
        return this.nr_Planete;
    }

}
