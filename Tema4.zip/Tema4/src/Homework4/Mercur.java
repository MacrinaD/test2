package Homework4;

public class Mercur extends SistemSolar implements Soare{
    private int temparatura;
    public Mercur(){

    }
    public Mercur(int temp)
    {
        this.temparatura=temp;
    }
    public Mercur(Mercur mercur)
    {
        temparatura=mercur.temparatura;
    }
    public void set_Temparatura(int temparatura)
    {
        this.temparatura=temparatura;
    }
    public int get_Temparatura()
    {
        return this.temparatura;
    }
    @Override

    public void luminaSolara()
    {
        System.out.println("LuminaSolara");
    }



}
