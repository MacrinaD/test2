package Homework4;

public interface Soare {
    void luminaSolara();
}
