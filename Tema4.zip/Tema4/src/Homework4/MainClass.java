package Homework4;

public class MainClass   {
    public static void main(String []args)
    {
        Mercur m =new Mercur();
        Mercur m2 =new Mercur(78);
        m.setPlanete(1);
        System.out.println(m.getPlanete());
        Mercur m3=m2;
        m.set_Temparatura(75879);
        System.out.println(m.get_Temparatura());

        m.luminaSolara();

        Terra pamant=new Terra();
        Terra t=new Terra(100);
        Terra t1=t;
        System.out.println(t1.get_Atmosfera());
        pamant.set_Atmosfera(455);
        System.out.println(pamant.get_Atmosfera());

        t.luminaSolara();




    }

}
