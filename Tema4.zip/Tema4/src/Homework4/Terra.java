package Homework4;

public class Terra extends SistemSolar implements Soare {
    private int atmosfera;
    public Terra(){

    }
    public Terra(int atm)
    {
        this.atmosfera=atm;
    }
    public Terra(Terra terra)
    {
        atmosfera=terra.atmosfera;
    }
    public void set_Atmosfera(int atmosfera){
        this.atmosfera=atmosfera;

    }
    public int get_Atmosfera(){
        return this.atmosfera;
    }

    @Override

    public void luminaSolara()
    {
        System.out.println("Lumina solara");
    }



}
